import { useState } from 'react';
import { SearchTabs } from './SearchTabs';
import { SearchForm } from './SearchForm';
import type { City, SearchFilters } from '@/types/hotel';

interface HeroSectionProps {
  cities: City[];
  filters: SearchFilters;
  onSearch: (filters: SearchFilters) => void;
}

export function HeroSection({ cities, filters, onSearch }: HeroSectionProps) {
  const [activeTab, setActiveTab] = useState('hotels');

  return (
    <section className="gradient-hero pt-12 pb-20 px-4">
      <div className="container mx-auto">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-primary-foreground text-center mb-10 text-balance">
          Здесь ищут кайфовые отели
        </h1>

        <div className="flex justify-center mb-8">
          <SearchTabs activeTab={activeTab} onTabChange={setActiveTab} />
        </div>

        <SearchForm cities={cities} filters={filters} onSearch={onSearch} />
      </div>
    </section>
  );
}

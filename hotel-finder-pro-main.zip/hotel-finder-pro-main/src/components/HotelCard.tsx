import { Heart, MapPin } from 'lucide-react';
import { StarRating } from './StarRating';
import { RatingBadge } from './RatingBadge';
import type { Hotel } from '@/types/hotel';

interface HotelCardProps {
  hotel: Hotel;
  onClick?: () => void;
}

function formatPrice(price: number): string {
  return price.toLocaleString('ru-RU');
}

export function HotelCard({ hotel, onClick }: HotelCardProps) {
  return (
    <article
      onClick={onClick}
      className="hotel-card group flex flex-col sm:flex-row animate-fade-in cursor-pointer"
    >
      {/* Image */}
      <div className="relative w-full sm:w-72 h-52 sm:h-auto flex-shrink-0">
        <img
          src={hotel.image_url || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800'}
          alt={hotel.name}
          className="w-full h-full object-cover"
        />
        <button
          onClick={(e) => {
            e.stopPropagation();
          }}
          className="absolute top-3 right-3 w-10 h-10 bg-card/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-card transition-colors"
        >
          <Heart className="w-5 h-5 text-muted-foreground hover:text-destructive transition-colors" />
        </button>
        {hotel.is_featured && (
          <span className="absolute top-3 left-3 px-3 py-1 bg-accent text-accent-foreground text-xs font-semibold rounded-full">
            Рекомендуем
          </span>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 p-5 flex flex-col">
        <div className="flex-1">
          {/* Header */}
          <div className="flex items-start justify-between gap-4 mb-2">
            <div>
              <StarRating stars={hotel.stars} className="mb-1" />
              <h3 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors line-clamp-1">
                {hotel.name}
              </h3>
            </div>
            <RatingBadge 
              rating={hotel.rating} 
              reviewsCount={hotel.reviews_count}
              showReviews
            />
          </div>

          {/* Location */}
          <div className="flex items-center gap-1 text-muted-foreground text-sm mb-3">
            <MapPin className="w-4 h-4" />
            <span>{hotel.address || (hotel.cities as any)?.name}</span>
          </div>

          {/* Description */}
          {hotel.description && (
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
              {hotel.description}
            </p>
          )}

          {/* Amenities */}
          <div className="flex flex-wrap gap-2 mb-4">
            {hotel.amenities.slice(0, 4).map((amenity) => (
              <span key={amenity} className="amenity-badge">
                {amenity}
              </span>
            ))}
            {hotel.amenities.length > 4 && (
              <span className="amenity-badge">
                +{hotel.amenities.length - 4}
              </span>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-end justify-between pt-3 border-t border-border">
          <div>
            {hotel.original_price && hotel.original_price > hotel.price_per_night && (
              <span className="price-original">
                {formatPrice(hotel.original_price)} сум
              </span>
            )}
            <div className="price-tag">
              {formatPrice(hotel.price_per_night)} <span className="text-base font-normal text-muted-foreground">сум/ночь</span>
            </div>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onClick?.();
            }}
            className="px-6 py-3 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 transition-colors"
          >
            Выбрать номер
          </button>
        </div>
      </div>
    </article>
  );
}

import { HotelCard } from './HotelCard';
import { SortDropdown } from './SortDropdown';
import { Skeleton } from '@/components/ui/skeleton';
import type { Hotel, SearchFilters } from '@/types/hotel';

interface HotelsListProps {
  hotels: Hotel[];
  isLoading: boolean;
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  onHotelClick: (hotel: Hotel) => void;
}

function HotelCardSkeleton() {
  return (
    <div className="bg-card rounded-2xl overflow-hidden shadow-card flex flex-col sm:flex-row">
      <Skeleton className="w-full sm:w-72 h-52" />
      <div className="flex-1 p-5">
        <Skeleton className="h-4 w-24 mb-2" />
        <Skeleton className="h-6 w-48 mb-3" />
        <Skeleton className="h-4 w-32 mb-3" />
        <Skeleton className="h-16 w-full mb-4" />
        <div className="flex gap-2 mb-4">
          <Skeleton className="h-6 w-16 rounded-full" />
          <Skeleton className="h-6 w-16 rounded-full" />
          <Skeleton className="h-6 w-16 rounded-full" />
        </div>
        <div className="flex items-end justify-between pt-3 border-t border-border">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-12 w-36 rounded-xl" />
        </div>
      </div>
    </div>
  );
}

export function HotelsList({ hotels, isLoading, filters, onFiltersChange, onHotelClick }: HotelsListProps) {
  const handleSortChange = (sortBy: SearchFilters['sortBy']) => {
    onFiltersChange({ ...filters, sortBy });
  };

  if (isLoading) {
    return (
      <div className="flex-1">
        <div className="flex items-center justify-between mb-6">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-10 w-40 rounded-xl" />
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <HotelCardSkeleton key={i} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1">
      <div className="flex items-center justify-between mb-6">
        <p className="text-muted-foreground">
          Найдено <span className="font-semibold text-foreground">{hotels.length}</span> отелей
        </p>
        <SortDropdown value={filters.sortBy} onChange={handleSortChange} />
      </div>

      {hotels.length === 0 ? (
        <div className="bg-card rounded-2xl p-12 text-center">
          <p className="text-lg text-muted-foreground mb-4">
            Отели не найдены
          </p>
          <p className="text-sm text-muted-foreground">
            Попробуйте изменить параметры поиска или фильтры
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {hotels.map((hotel) => (
            <HotelCard
              key={hotel.id}
              hotel={hotel}
              onClick={() => onHotelClick(hotel)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

import { cn } from '@/lib/utils';

interface RatingBadgeProps {
  rating: number | null;
  reviewsCount?: number | null;
  showReviews?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

function getRatingClass(rating: number): string {
  if (rating >= 8.5) return 'bg-rating-excellent';
  if (rating >= 7) return 'bg-rating-good';
  return 'bg-rating-average';
}

function getRatingText(rating: number): string {
  if (rating >= 9) return 'Превосходно';
  if (rating >= 8) return 'Отлично';
  if (rating >= 7) return 'Очень хорошо';
  if (rating >= 6) return 'Хорошо';
  return 'Нормально';
}

function formatReviews(count: number): string {
  if (count >= 1000) {
    return `${(count / 1000).toFixed(1)}K`;
  }
  return count.toString();
}

export function RatingBadge({ rating, reviewsCount, showReviews = false, size = 'md' }: RatingBadgeProps) {
  if (!rating) return null;

  const sizeClasses = {
    sm: 'text-xs px-1.5 py-0.5',
    md: 'text-sm px-2 py-1',
    lg: 'text-base px-3 py-1.5',
  };

  return (
    <div className="flex items-center gap-2">
      <span className={cn(
        "inline-flex items-center justify-center rounded-lg font-bold text-primary-foreground",
        getRatingClass(rating),
        sizeClasses[size]
      )}>
        {rating.toFixed(1)}
      </span>
      {showReviews && (
        <div className="flex flex-col">
          <span className="text-sm font-medium text-foreground">{getRatingText(rating)}</span>
          {reviewsCount && (
            <span className="text-xs text-muted-foreground">{formatReviews(reviewsCount)} отзывов</span>
          )}
        </div>
      )}
    </div>
  );
}

import { User, HelpCircle, Globe } from 'lucide-react';

export function Header() {
  return (
    <header className="w-full bg-primary">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary-foreground/20 rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">H</span>
            </div>
            <span className="text-primary-foreground font-bold text-xl hidden sm:block">
              hotels
            </span>
          </a>

          {/* Right side navigation */}
          <nav className="flex items-center gap-2 sm:gap-4">
            <a
              href="#"
              className="flex items-center gap-2 text-primary-foreground/90 hover:text-primary-foreground transition-colors px-3 py-2 rounded-lg hover:bg-primary-foreground/10"
            >
              <User className="w-4 h-4" />
              <span className="hidden sm:inline text-sm font-medium">Профиль</span>
            </a>
            <a
              href="#"
              className="flex items-center gap-2 text-primary-foreground/90 hover:text-primary-foreground transition-colors px-3 py-2 rounded-lg hover:bg-primary-foreground/10"
            >
              <HelpCircle className="w-4 h-4" />
              <span className="hidden sm:inline text-sm font-medium">Поддержка</span>
            </a>
            <button className="flex items-center gap-2 text-primary-foreground/90 hover:text-primary-foreground transition-colors px-3 py-2 rounded-lg hover:bg-primary-foreground/10">
              <Globe className="w-4 h-4" />
              <span className="text-sm font-medium">RU</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
}

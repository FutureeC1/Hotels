import { Star, MapPin } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import type { Hotel } from '@/types/hotel';

interface FeaturedHotelsProps {
  hotels: Hotel[];
  isLoading: boolean;
  onHotelClick: (hotel: Hotel) => void;
}

function formatPrice(price: number): string {
  return price.toLocaleString('ru-RU');
}

function FeaturedCardSkeleton() {
  return (
    <div className="bg-card rounded-2xl overflow-hidden shadow-card">
      <Skeleton className="w-full h-48" />
      <div className="p-4">
        <Skeleton className="h-5 w-32 mb-2" />
        <Skeleton className="h-4 w-24 mb-3" />
        <div className="flex items-center justify-between">
          <Skeleton className="h-6 w-28" />
          <Skeleton className="h-6 w-12" />
        </div>
      </div>
    </div>
  );
}

export function FeaturedHotels({ hotels, isLoading, onHotelClick }: FeaturedHotelsProps) {
  if (isLoading) {
    return (
      <section className="container mx-auto px-4 py-12">
        <Skeleton className="h-8 w-64 mb-6" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <FeaturedCardSkeleton key={i} />
          ))}
        </div>
      </section>
    );
  }

  if (hotels.length === 0) return null;

  return (
    <section className="container mx-auto px-4 py-12">
      <h2 className="text-2xl font-bold mb-6">Рекомендуемые отели</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {hotels.map((hotel) => (
          <article
            key={hotel.id}
            onClick={() => onHotelClick(hotel)}
            className="bg-card rounded-2xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300 cursor-pointer group"
          >
            <div className="relative h-48">
              <img
                src={hotel.image_url || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800'}
                alt={hotel.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              {hotel.original_price && hotel.original_price > hotel.price_per_night && (
                <span className="absolute top-3 left-3 px-2 py-1 bg-destructive text-destructive-foreground text-xs font-semibold rounded-full">
                  -{Math.round((1 - hotel.price_per_night / hotel.original_price) * 100)}%
                </span>
              )}
            </div>
            <div className="p-4">
              <div className="flex items-center gap-1 mb-1">
                {Array.from({ length: hotel.stars || 0 }).map((_, i) => (
                  <Star key={i} className="w-3 h-3 text-aviasales-yellow fill-current" />
                ))}
              </div>
              <h3 className="font-bold text-lg mb-1 line-clamp-1 group-hover:text-primary transition-colors">
                {hotel.name}
              </h3>
              <div className="flex items-center gap-1 text-muted-foreground text-sm mb-3">
                <MapPin className="w-3 h-3" />
                <span>{(hotel.cities as any)?.name}</span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-lg">{formatPrice(hotel.price_per_night)}</span>
                  <span className="text-muted-foreground text-sm"> сум/ночь</span>
                </div>
                {hotel.rating && (
                  <span className="rating-badge rating-excellent">
                    {hotel.rating.toFixed(1)}
                  </span>
                )}
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

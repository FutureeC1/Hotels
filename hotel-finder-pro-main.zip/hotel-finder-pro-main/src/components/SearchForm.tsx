import { useState, useRef, useEffect } from 'react';
import { Search, Calendar, Users, MapPin } from 'lucide-react';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import type { City, SearchFilters } from '@/types/hotel';

interface SearchFormProps {
  cities: City[];
  filters: SearchFilters;
  onSearch: (filters: SearchFilters) => void;
}

export function SearchForm({ cities, filters, onSearch }: SearchFormProps) {
  const [cityQuery, setCityQuery] = useState(filters.cityName || '');
  const [showCitySuggestions, setShowCitySuggestions] = useState(false);
  const [checkIn, setCheckIn] = useState<Date | undefined>(filters.checkIn);
  const [checkOut, setCheckOut] = useState<Date | undefined>(filters.checkOut);
  const [guests, setGuests] = useState(filters.guests);
  const [showGuestsDropdown, setShowGuestsDropdown] = useState(false);
  const cityInputRef = useRef<HTMLInputElement>(null);

  const filteredCities = cities.filter(city =>
    city.name.toLowerCase().includes(cityQuery.toLowerCase())
  );

  const handleCitySelect = (city: City) => {
    setCityQuery(city.name);
    setShowCitySuggestions(false);
  };

  const handleSearch = () => {
    const selectedCity = cities.find(c => c.name.toLowerCase() === cityQuery.toLowerCase());
    onSearch({
      ...filters,
      cityId: selectedCity?.id,
      cityName: cityQuery,
      checkIn,
      checkOut,
      guests,
    });
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (cityInputRef.current && !cityInputRef.current.contains(e.target as Node)) {
        setShowCitySuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="w-full max-w-5xl mx-auto">
      <div className="bg-card rounded-2xl shadow-search p-2 flex flex-col lg:flex-row gap-2">
        {/* City Input */}
        <div className="relative flex-1" ref={cityInputRef}>
          <div className="relative">
            <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              value={cityQuery}
              onChange={(e) => {
                setCityQuery(e.target.value);
                setShowCitySuggestions(true);
              }}
              onFocus={() => setShowCitySuggestions(true)}
              placeholder="Город или отель"
              className="w-full h-14 pl-12 pr-4 bg-secondary rounded-xl text-base placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>
          {showCitySuggestions && filteredCities.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-card rounded-xl shadow-lg border border-border z-50 overflow-hidden">
              {filteredCities.map((city) => (
                <button
                  key={city.id}
                  onClick={() => handleCitySelect(city)}
                  className="w-full px-4 py-3 text-left hover:bg-secondary transition-colors flex items-center gap-3"
                >
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <div className="font-medium">{city.name}</div>
                    <div className="text-sm text-muted-foreground">{city.country}</div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Check-in Date */}
        <Popover>
          <PopoverTrigger asChild>
            <button className="h-14 px-4 bg-secondary rounded-xl flex items-center gap-3 hover:bg-secondary/80 transition-colors min-w-[160px]">
              <Calendar className="w-5 h-5 text-muted-foreground" />
              <span className={cn(
                "text-base",
                !checkIn && "text-muted-foreground"
              )}>
                {checkIn ? format(checkIn, 'd MMM', { locale: ru }) : 'Дата заезда'}
              </span>
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <CalendarComponent
              mode="single"
              selected={checkIn}
              onSelect={setCheckIn}
              disabled={(date) => date < new Date()}
              initialFocus
              className="pointer-events-auto"
            />
          </PopoverContent>
        </Popover>

        {/* Check-out Date */}
        <Popover>
          <PopoverTrigger asChild>
            <button className="h-14 px-4 bg-secondary rounded-xl flex items-center gap-3 hover:bg-secondary/80 transition-colors min-w-[160px]">
              <Calendar className="w-5 h-5 text-muted-foreground" />
              <span className={cn(
                "text-base",
                !checkOut && "text-muted-foreground"
              )}>
                {checkOut ? format(checkOut, 'd MMM', { locale: ru }) : 'Дата выезда'}
              </span>
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <CalendarComponent
              mode="single"
              selected={checkOut}
              onSelect={setCheckOut}
              disabled={(date) => date < (checkIn || new Date())}
              initialFocus
              className="pointer-events-auto"
            />
          </PopoverContent>
        </Popover>

        {/* Guests */}
        <div className="relative">
          <button
            onClick={() => setShowGuestsDropdown(!showGuestsDropdown)}
            className="h-14 px-4 bg-secondary rounded-xl flex items-center gap-3 hover:bg-secondary/80 transition-colors min-w-[140px]"
          >
            <Users className="w-5 h-5 text-muted-foreground" />
            <span className="text-base">{guests} {guests === 1 ? 'гость' : guests < 5 ? 'гостя' : 'гостей'}</span>
          </button>
          {showGuestsDropdown && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-card rounded-xl shadow-lg border border-border z-50 p-4">
              <div className="flex items-center justify-between">
                <span className="font-medium">Гости</span>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setGuests(Math.max(1, guests - 1))}
                    className="w-8 h-8 rounded-full border border-border flex items-center justify-center hover:bg-secondary transition-colors"
                  >
                    -
                  </button>
                  <span className="w-6 text-center font-medium">{guests}</span>
                  <button
                    onClick={() => setGuests(Math.min(10, guests + 1))}
                    className="w-8 h-8 rounded-full border border-border flex items-center justify-center hover:bg-secondary transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>
              <button
                onClick={() => setShowGuestsDropdown(false)}
                className="w-full mt-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
              >
                Готово
              </button>
            </div>
          )}
        </div>

        {/* Search Button */}
        <button
          onClick={handleSearch}
          className="h-14 px-8 bg-accent text-accent-foreground font-semibold rounded-xl hover:bg-aviasales-orange-hover transition-all duration-200 shadow-button flex items-center justify-center gap-2"
        >
          <Search className="w-5 h-5" />
          <span>Найти отели</span>
        </button>
      </div>
    </div>
  );
}

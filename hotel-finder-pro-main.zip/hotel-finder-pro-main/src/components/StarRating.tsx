import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StarRatingProps {
  stars: number | null;
  className?: string;
}

export function StarRating({ stars, className }: StarRatingProps) {
  if (!stars) return null;
  
  return (
    <div className={cn("flex items-center gap-0.5", className)}>
      {Array.from({ length: stars }).map((_, i) => (
        <Star key={i} className="w-4 h-4 text-aviasales-yellow fill-current" />
      ))}
    </div>
  );
}

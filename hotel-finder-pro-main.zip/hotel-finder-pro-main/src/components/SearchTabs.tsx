import { Plane, Building2, MapPin, Heart } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SearchTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const tabs = [
  { id: 'flights', label: 'Авиабилеты', icon: Plane },
  { id: 'hotels', label: 'Отели', icon: Building2 },
  { id: 'guides', label: 'Гиды', icon: MapPin },
  { id: 'favorites', label: 'Избранное', icon: Heart },
];

export function SearchTabs({ activeTab, onTabChange }: SearchTabsProps) {
  return (
    <div className="inline-flex bg-primary-foreground/10 rounded-2xl p-1">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              'flex items-center gap-2 px-4 sm:px-6 py-3 rounded-xl font-medium transition-all duration-200',
              isActive
                ? 'bg-card text-foreground shadow-md'
                : 'text-primary-foreground/90 hover:bg-primary-foreground/10'
            )}
          >
            <Icon className="w-5 h-5" />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}

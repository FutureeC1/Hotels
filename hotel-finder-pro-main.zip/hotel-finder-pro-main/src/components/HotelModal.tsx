import { X, MapPin, Star, Wifi, Car, Utensils, Dumbbell, Waves } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { StarRating } from './StarRating';
import { RatingBadge } from './RatingBadge';
import type { Hotel } from '@/types/hotel';

interface HotelModalProps {
  hotel: Hotel | null;
  isOpen: boolean;
  onClose: () => void;
}

const AMENITY_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  'Wi-Fi': Wifi,
  'Парковка': Car,
  'Ресторан': Utensils,
  'Фитнес': Dumbbell,
  'Бассейн': Waves,
};

function formatPrice(price: number): string {
  return price.toLocaleString('ru-RU');
}

export function HotelModal({ hotel, isOpen, onClose }: HotelModalProps) {
  if (!hotel) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto p-0">
        {/* Hero Image */}
        <div className="relative h-64 sm:h-80">
          <img
            src={hotel.image_url || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800'}
            alt={hotel.name}
            className="w-full h-full object-cover"
          />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-10 h-10 bg-card/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-card transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <DialogHeader className="mb-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <StarRating stars={hotel.stars} className="mb-2" />
                <DialogTitle className="text-2xl font-bold">{hotel.name}</DialogTitle>
                <div className="flex items-center gap-1 text-muted-foreground mt-2">
                  <MapPin className="w-4 h-4" />
                  <span>{hotel.address || (hotel.cities as any)?.name}</span>
                </div>
              </div>
              <RatingBadge
                rating={hotel.rating}
                reviewsCount={hotel.reviews_count}
                showReviews
                size="lg"
              />
            </div>
          </DialogHeader>

          {/* Description */}
          {hotel.description && (
            <div className="mb-6">
              <h3 className="font-semibold mb-2">Об отеле</h3>
              <p className="text-muted-foreground">{hotel.description}</p>
            </div>
          )}

          {/* Amenities */}
          <div className="mb-6">
            <h3 className="font-semibold mb-3">Удобства</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {hotel.amenities.map((amenity) => {
                const Icon = AMENITY_ICONS[amenity] || Star;
                return (
                  <div
                    key={amenity}
                    className="flex items-center gap-2 p-3 bg-secondary rounded-xl"
                  >
                    <Icon className="w-5 h-5 text-primary" />
                    <span className="text-sm">{amenity}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Price & Booking */}
          <div className="flex items-center justify-between p-4 bg-secondary rounded-2xl">
            <div>
              {hotel.original_price && hotel.original_price > hotel.price_per_night && (
                <span className="price-original">
                  {formatPrice(hotel.original_price)} сум
                </span>
              )}
              <div className="text-2xl font-bold">
                {formatPrice(hotel.price_per_night)} <span className="text-base font-normal text-muted-foreground">сум/ночь</span>
              </div>
            </div>
            <button className="px-8 py-4 bg-accent text-accent-foreground font-semibold rounded-xl hover:bg-aviasales-orange-hover transition-colors shadow-button">
              Забронировать
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

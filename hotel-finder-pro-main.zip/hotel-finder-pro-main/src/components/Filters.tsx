import { useState } from 'react';
import { ChevronDown, ChevronUp, Star } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import type { SearchFilters } from '@/types/hotel';

interface FiltersProps {
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
}

const AMENITIES = [
  'Wi-Fi',
  'Бассейн',
  'Спа',
  'Фитнес',
  'Ресторан',
  'Парковка',
  'Кондиционер',
  'Бизнес-центр',
  'Терраса',
  'Сад',
];

const PRICE_RANGE = { min: 0, max: 300000 };

export function Filters({ filters, onFiltersChange }: FiltersProps) {
  const [expandedSections, setExpandedSections] = useState({
    price: true,
    rating: true,
    stars: true,
    amenities: true,
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handlePriceChange = (values: number[]) => {
    onFiltersChange({
      ...filters,
      minPrice: values[0],
      maxPrice: values[1],
    });
  };

  const handleRatingChange = (rating: number) => {
    onFiltersChange({
      ...filters,
      minRating: filters.minRating === rating ? undefined : rating,
    });
  };

  const handleStarsChange = (star: number) => {
    const currentStars = filters.stars || [];
    const newStars = currentStars.includes(star)
      ? currentStars.filter(s => s !== star)
      : [...currentStars, star];
    
    onFiltersChange({
      ...filters,
      stars: newStars.length > 0 ? newStars : undefined,
    });
  };

  const handleAmenityChange = (amenity: string) => {
    const currentAmenities = filters.amenities || [];
    const newAmenities = currentAmenities.includes(amenity)
      ? currentAmenities.filter(a => a !== amenity)
      : [...currentAmenities, amenity];
    
    onFiltersChange({
      ...filters,
      amenities: newAmenities.length > 0 ? newAmenities : undefined,
    });
  };

  const formatPrice = (price: number) => {
    if (price >= 1000) {
      return `${Math.round(price / 1000)}K`;
    }
    return price.toString();
  };

  return (
    <aside className="bg-card rounded-2xl p-5 shadow-card">
      <h2 className="text-lg font-bold mb-5">Фильтры</h2>

      {/* Price Range */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('price')}
          className="flex items-center justify-between w-full mb-4"
        >
          <span className="font-semibold">Цена за ночь</span>
          {expandedSections.price ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
        {expandedSections.price && (
          <div>
            <Slider
              defaultValue={[filters.minPrice || PRICE_RANGE.min, filters.maxPrice || PRICE_RANGE.max]}
              max={PRICE_RANGE.max}
              min={PRICE_RANGE.min}
              step={5000}
              onValueChange={handlePriceChange}
              className="mb-3"
            />
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>{formatPrice(filters.minPrice || PRICE_RANGE.min)} сум</span>
              <span>{formatPrice(filters.maxPrice || PRICE_RANGE.max)} сум</span>
            </div>
          </div>
        )}
      </div>

      {/* Rating */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('rating')}
          className="flex items-center justify-between w-full mb-4"
        >
          <span className="font-semibold">Рейтинг</span>
          {expandedSections.rating ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
        {expandedSections.rating && (
          <div className="flex flex-wrap gap-2">
            {[9, 8, 7, 6].map((rating) => (
              <button
                key={rating}
                onClick={() => handleRatingChange(rating)}
                className={cn(
                  "px-4 py-2 rounded-xl text-sm font-medium border transition-colors",
                  filters.minRating === rating
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border hover:border-primary/50"
                )}
              >
                {rating}+
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Stars */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('stars')}
          className="flex items-center justify-between w-full mb-4"
        >
          <span className="font-semibold">Звёзды</span>
          {expandedSections.stars ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
        {expandedSections.stars && (
          <div className="space-y-3">
            {[5, 4, 3, 2, 1].map((star) => (
              <label
                key={star}
                className="flex items-center gap-3 cursor-pointer group"
              >
                <Checkbox
                  checked={filters.stars?.includes(star) || false}
                  onCheckedChange={() => handleStarsChange(star)}
                />
                <div className="flex items-center gap-1">
                  {Array.from({ length: star }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-aviasales-yellow fill-current" />
                  ))}
                </div>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Amenities */}
      <div>
        <button
          onClick={() => toggleSection('amenities')}
          className="flex items-center justify-between w-full mb-4"
        >
          <span className="font-semibold">Удобства</span>
          {expandedSections.amenities ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
        {expandedSections.amenities && (
          <div className="space-y-3">
            {AMENITIES.map((amenity) => (
              <label
                key={amenity}
                className="flex items-center gap-3 cursor-pointer"
              >
                <Checkbox
                  checked={filters.amenities?.includes(amenity) || false}
                  onCheckedChange={() => handleAmenityChange(amenity)}
                />
                <span className="text-sm">{amenity}</span>
              </label>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
}

import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Hotel, City, SearchFilters } from '@/types/hotel';

export function useCities() {
  return useQuery({
    queryKey: ['cities'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('cities')
        .select('*')
        .order('name');
      
      if (error) throw error;
      return data as City[];
    },
  });
}

export function useHotels(filters: SearchFilters) {
  return useQuery({
    queryKey: ['hotels', filters],
    queryFn: async () => {
      let query = supabase
        .from('hotels')
        .select('*, cities(*)');

      // Filter by city
      if (filters.cityId) {
        query = query.eq('city_id', filters.cityId);
      }

      // Filter by price range
      if (filters.minPrice !== undefined) {
        query = query.gte('price_per_night', filters.minPrice);
      }
      if (filters.maxPrice !== undefined) {
        query = query.lte('price_per_night', filters.maxPrice);
      }

      // Filter by rating
      if (filters.minRating !== undefined) {
        query = query.gte('rating', filters.minRating);
      }

      // Filter by stars
      if (filters.stars && filters.stars.length > 0) {
        query = query.in('stars', filters.stars);
      }

      // Sorting
      switch (filters.sortBy) {
        case 'price_asc':
          query = query.order('price_per_night', { ascending: true });
          break;
        case 'price_desc':
          query = query.order('price_per_night', { ascending: false });
          break;
        case 'rating_desc':
          query = query.order('rating', { ascending: false, nullsFirst: false });
          break;
        case 'reviews_desc':
          query = query.order('reviews_count', { ascending: false, nullsFirst: false });
          break;
        default:
          query = query.order('is_featured', { ascending: false }).order('rating', { ascending: false, nullsFirst: false });
      }

      const { data, error } = await query;
      
      if (error) throw error;
      
      // Filter by amenities in JS (since array contains is complex in Supabase)
      let hotels = data as Hotel[];
      if (filters.amenities && filters.amenities.length > 0) {
        hotels = hotels.filter(hotel => 
          filters.amenities!.every(amenity => 
            hotel.amenities.includes(amenity)
          )
        );
      }

      return hotels;
    },
  });
}

export function useHotel(id: string) {
  return useQuery({
    queryKey: ['hotel', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hotels')
        .select('*, cities(*)')
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return data as Hotel;
    },
    enabled: !!id,
  });
}

export function useFeaturedHotels() {
  return useQuery({
    queryKey: ['featured-hotels'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hotels')
        .select('*, cities(*)')
        .eq('is_featured', true)
        .order('rating', { ascending: false })
        .limit(6);
      
      if (error) throw error;
      return data as Hotel[];
    },
  });
}

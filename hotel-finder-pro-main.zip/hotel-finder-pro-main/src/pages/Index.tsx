import { useState } from 'react';
import { Header } from '@/components/Header';
import { HeroSection } from '@/components/HeroSection';
import { Filters } from '@/components/Filters';
import { HotelsList } from '@/components/HotelsList';
import { FeaturedHotels } from '@/components/FeaturedHotels';
import { HotelModal } from '@/components/HotelModal';
import { Footer } from '@/components/Footer';
import { useCities, useHotels, useFeaturedHotels } from '@/hooks/useHotels';
import type { Hotel, SearchFilters } from '@/types/hotel';

const defaultFilters: SearchFilters = {
  guests: 2,
  sortBy: 'rating_desc',
};

export default function Index() {
  const [filters, setFilters] = useState<SearchFilters>(defaultFilters);
  const [hasSearched, setHasSearched] = useState(false);
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);

  const { data: cities = [], isLoading: citiesLoading } = useCities();
  const { data: hotels = [], isLoading: hotelsLoading } = useHotels(filters);
  const { data: featuredHotels = [], isLoading: featuredLoading } = useFeaturedHotels();

  const handleSearch = (newFilters: SearchFilters) => {
    setFilters(newFilters);
    setHasSearched(true);
  };

  const handleFiltersChange = (newFilters: SearchFilters) => {
    setFilters(newFilters);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <HeroSection
        cities={cities}
        filters={filters}
        onSearch={handleSearch}
      />

      {hasSearched ? (
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Filters Sidebar */}
            <div className="w-full lg:w-72 flex-shrink-0">
              <Filters filters={filters} onFiltersChange={handleFiltersChange} />
            </div>

            {/* Hotels List */}
            <HotelsList
              hotels={hotels}
              isLoading={hotelsLoading}
              filters={filters}
              onFiltersChange={handleFiltersChange}
              onHotelClick={setSelectedHotel}
            />
          </div>
        </div>
      ) : (
        <FeaturedHotels
          hotels={featuredHotels}
          isLoading={featuredLoading}
          onHotelClick={setSelectedHotel}
        />
      )}

      <HotelModal
        hotel={selectedHotel}
        isOpen={!!selectedHotel}
        onClose={() => setSelectedHotel(null)}
      />

      <Footer />
    </div>
  );
}

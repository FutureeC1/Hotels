export interface City {
  id: string;
  name: string;
  country: string;
  image_url: string | null;
  created_at: string;
}

export interface Hotel {
  id: string;
  city_id: string;
  name: string;
  description: string | null;
  address: string | null;
  stars: number | null;
  rating: number | null;
  reviews_count: number | null;
  price_per_night: number;
  original_price: number | null;
  image_url: string | null;
  images: string[];
  amenities: string[];
  latitude: number | null;
  longitude: number | null;
  is_featured: boolean;
  created_at: string;
  cities?: City;
}

export interface Room {
  id: string;
  hotel_id: string;
  name: string;
  description: string | null;
  capacity: number;
  price_per_night: number;
  amenities: string[];
  images: string[];
  available: boolean;
  created_at: string;
}

export interface Booking {
  id: string;
  user_id: string;
  room_id: string;
  hotel_id: string;
  check_in: string;
  check_out: string;
  guests: number;
  total_price: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  created_at: string;
}

export interface SearchFilters {
  cityId?: string;
  cityName?: string;
  checkIn?: Date;
  checkOut?: Date;
  guests: number;
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  stars?: number[];
  amenities?: string[];
  sortBy: 'price_asc' | 'price_desc' | 'rating_desc' | 'reviews_desc';
}
